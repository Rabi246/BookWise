package gg.jte.generated.ondemand;
@SuppressWarnings("unchecked")
public final class JteloginGenerated {
	public static final String JTE_NAME = "login.jte";
	public static final int[] JTE_LINE_INFO = {6,6,6,6,6,6,6,9,12,56,56,56,56,56,56};
	public static void render(gg.jte.html.HtmlTemplateOutput jteOutput, gg.jte.html.HtmlInterceptor jteHtmlInterceptor) {
		jteOutput.writeContent("<!DOCTYPE html>\r\n<html>\r\n<head>\r\n    <meta charset=\"UTF-8\">\r\n    <title>Login | BookWise</title>\r\n\r\n    ");
		jteOutput.writeContent("\r\n    <link href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css\" rel=\"stylesheet\">\r\n\r\n    ");
		jteOutput.writeContent("\r\n    <link rel=\"stylesheet\" href=\"/css/style.css\">\r\n\r\n    ");
		jteOutput.writeContent("\r\n    <link href=\"https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css\" rel=\"stylesheet\">\r\n</head>\r\n\r\n<body>\r\n\r\n<div class=\"auth-container\">\r\n    <div class=\"auth-card\">\r\n\r\n        <div class=\"top-logo\">\r\n            <i class=\"bi bi-bookmark-fill\"></i>\r\n            BookWise\r\n        </div>\r\n\r\n        <h2>Login</h2>\r\n\r\n        <form method=\"post\" action=\"/login\">\r\n\r\n            <label class=\"auth-label\">Username</label>\r\n            <input class=\"form-control mb-3\" name=\"username\" required>\r\n\r\n            <label class=\"auth-label\">Password</label>\r\n            <input class=\"form-control mb-2\" type=\"password\" name=\"password\" required>\r\n\r\n            <div class=\"text-end mb-3\">\r\n                <a href=\"/forgot_password\">Forgot password?</a>\r\n            </div>\r\n\r\n            <button class=\"btn-primary-custom\">Submit</button>\r\n        </form>\r\n\r\n        <p class=\"auth-footer\">\r\n            New to BookWise? <a href=\"/register\">Create an account</a>\r\n        </p>\r\n\r\n    </div>\r\n</div>\r\n\r\n<div class=\"auth-footer\">\r\n    <i class=\"bi bi-bookmark-fill\"></i> BookWise.io © 2025 AI Book Recommendations.\r\n</div>\r\n\r\n</body>\r\n</html>\r\n");
	}
	public static void renderMap(gg.jte.html.HtmlTemplateOutput jteOutput, gg.jte.html.HtmlInterceptor jteHtmlInterceptor, java.util.Map<String, Object> params) {
		render(jteOutput, jteHtmlInterceptor);
	}
}
