package gg.jte.generated.ondemand;
@SuppressWarnings("unchecked")
public final class JteloginGenerated {
	public static final String JTE_NAME = "login.jte";
	public static final int[] JTE_LINE_INFO = {0,0,0,0,0,17,17,17,18,18,18,20,20,37,37,37,0,0,0,0};
	public static void render(gg.jte.html.HtmlTemplateOutput jteOutput, gg.jte.html.HtmlInterceptor jteHtmlInterceptor, String error) {
		jteOutput.writeContent("\r\n<!DOCTYPE html>\r\n<html lang=\"en\">\r\n<head>\r\n    <meta charset=\"UTF-8\">\r\n    <title>Login | BookWise</title>\r\n    <link href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css\" rel=\"stylesheet\">\r\n    <link rel=\"stylesheet\" href=\"/css/style.css\">\r\n    <link href=\"https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css\" rel=\"stylesheet\">\r\n</head>\r\n<body>\r\n<div class=\"auth-container\">\r\n    <div class=\"auth-card\">\r\n        <div class=\"top-logo\"><i class=\"bi bi-bookmark-fill\"></i> BookWise</div>\r\n        <h2>Login</h2>\r\n\r\n        ");
		if (error != null) {
			jteOutput.writeContent("\r\n        <div class=\"alert alert-danger mb-3\">");
			jteOutput.setContext("div", null);
			jteOutput.writeUserContent(error);
			jteOutput.writeContent("</div>\r\n\r\n        ");
		}
		jteOutput.writeContent("\r\n        <form method=\"post\" action=\"/login\">\r\n            <label class=\"auth-label\">Username</label>\r\n            <input class=\"form-control mb-3\" name=\"username\" required>\r\n            <label class=\"auth-label\">Password</label>\r\n            <input class=\"form-control mb-2\" type=\"password\" name=\"password\" required>\r\n            <div class=\"text-end mb-3\"><a href=\"/forgot_password\">Forgot password?</a></div>\r\n            <button class=\"btn-primary-custom\">Submit</button>\r\n        </form>\r\n\r\n        <p class=\"auth-footer\">New to BookWise? <a href=\"/register\">Create an account</a></p>\r\n    </div>\r\n</div>\r\n<div class=\"auth-footer\"><i class=\"bi bi-bookmark-fill\"></i> BookWise.io © 2025 AI Book Recommendations.</div>\r\n</body>\r\n</html>\r\n\r\n");
	}
	public static void renderMap(gg.jte.html.HtmlTemplateOutput jteOutput, gg.jte.html.HtmlInterceptor jteHtmlInterceptor, java.util.Map<String, Object> params) {
		String error = (String)params.get("error");
		render(jteOutput, jteHtmlInterceptor, error);
	}
}
