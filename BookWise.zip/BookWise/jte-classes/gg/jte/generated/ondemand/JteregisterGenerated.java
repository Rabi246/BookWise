package gg.jte.generated.ondemand;
@SuppressWarnings("unchecked")
public final class JteregisterGenerated {
	public static final String JTE_NAME = "register.jte";
	public static final int[] JTE_LINE_INFO = {0,0,0,0,0,17,17,17,18,18,18,20,20,41,41,41,0,0,0,0};
	public static void render(gg.jte.html.HtmlTemplateOutput jteOutput, gg.jte.html.HtmlInterceptor jteHtmlInterceptor, String error) {
		jteOutput.writeContent("\r\n<!DOCTYPE html>\r\n<html>\r\n<head>\r\n    <meta charset=\"UTF-8\">\r\n    <title>Create Account | BookWise</title>\r\n    <link href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css\" rel=\"stylesheet\">\r\n    <link rel=\"stylesheet\" href=\"/css/style.css\">\r\n    <link href=\"https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css\" rel=\"stylesheet\">\r\n</head>\r\n<body>\r\n<div class=\"auth-container\">\r\n    <div class=\"auth-card\">\r\n        <div class=\"top-logo\"><i class=\"bi bi-bookmark-fill\"></i> BookWise</div>\r\n        <h2>Create Account</h2>\r\n\r\n        ");
		if (error != null) {
			jteOutput.writeContent("\r\n        <div class=\"alert alert-danger mb-3\">");
			jteOutput.setContext("div", null);
			jteOutput.writeUserContent(error);
			jteOutput.writeContent("</div>\r\n\r\n        ");
		}
		jteOutput.writeContent("\r\n        <form method=\"post\" action=\"/register\">\r\n            <label class=\"auth-label\">Full Name</label>\r\n            <input class=\"form-control mb-2\" name=\"name\" required>\r\n            <label class=\"auth-label\">Username</label>\r\n            <input class=\"form-control mb-2\" name=\"username\" required>\r\n            <label class=\"auth-label\">Email</label>\r\n            <input class=\"form-control mb-2\" type=\"email\" name=\"email\" required>\r\n            <label class=\"auth-label\">Password</label>\r\n            <input class=\"form-control mb-2\" type=\"password\" name=\"password\" required>\r\n            <label class=\"auth-label\">Confirm Password</label>\r\n            <input class=\"form-control mb-3\" type=\"password\" name=\"confirmPassword\" required>\r\n            <button class=\"btn-primary-custom\">Create Account</button>\r\n        </form>\r\n\r\n        <p class=\"auth-footer\">Already have an account? <a href=\"/login\">Login here</a></p>\r\n    </div>\r\n</div>\r\n<div class=\"auth-footer\"><i class=\"bi bi-bookmark-fill\"></i> BookWise.io © 2025 AI Book Recommendations.</div>\r\n</body>\r\n</html>\r\n");
	}
	public static void renderMap(gg.jte.html.HtmlTemplateOutput jteOutput, gg.jte.html.HtmlInterceptor jteHtmlInterceptor, java.util.Map<String, Object> params) {
		String error = (String)params.get("error");
		render(jteOutput, jteHtmlInterceptor, error);
	}
}
