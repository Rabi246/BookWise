package gg.jte.generated.ondemand;
import org.example.bookwise.Exchange;
import java.util.List;
@SuppressWarnings("unchecked")
public final class Jtehome_pageGenerated {
	public static final String JTE_NAME = "home_page.jte";
	public static final int[] JTE_LINE_INFO = {0,0,1,2,2,2,2,22,22,31,31,32,32,33,33,33,34,34,34,35,35,36,36,38,38,52,74,109,111,111,111,2,2,2,2};
	public static void render(gg.jte.html.HtmlTemplateOutput jteOutput, gg.jte.html.HtmlInterceptor jteHtmlInterceptor, List<Exchange> history) {
		jteOutput.writeContent("\r\n<!DOCTYPE html>\r\n<html lang=\"en\">\r\n<head>\r\n    <meta charset=\"UTF-8\">\r\n    <title>BookWise | Recommendations</title>\r\n    <link href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css\" rel=\"stylesheet\">\r\n</head>\r\n<body class=\"bg-light\">\r\n\r\n<nav class=\"navbar navbar-expand-lg navbar-dark bg-dark mb-4\">\r\n    <div class=\"container-fluid\">\r\n        <a class=\"navbar-brand\" href=\"/home_page\">📚 BookWise</a>\r\n    </div>\r\n</nav>\r\n\r\n<div class=\"container\">\r\n    <div class=\"row g-4\">\r\n\r\n        ");
		jteOutput.writeContent("\r\n        <div class=\"col-md-6\">\r\n            <div class=\"card shadow-lg h-100\">\r\n                <div class=\"card-header bg-primary text-white\">\r\n                    🤖 AI Book Assistant\r\n                </div>\r\n                <div class=\"card-body d-flex flex-column\">\r\n\r\n                    <div class=\"chat-window mb-3\" style=\"height:350px; overflow-y:auto; border:1px solid #ddd; padding:10px;\">\r\n                        ");
		if (history != null && !history.isEmpty()) {
			jteOutput.writeContent("\r\n                            ");
			for (var exchange : history) {
				jteOutput.writeContent("\r\n                                <div class=\"mb-2\"><strong>You:</strong> ");
				jteOutput.setContext("div", null);
				jteOutput.writeUserContent(exchange.getUserMessage());
				jteOutput.writeContent("</div>\r\n                                <div class=\"mb-3 text-success\"><strong>AI:</strong> ");
				jteOutput.setContext("div", null);
				jteOutput.writeUserContent(exchange.getAiMessage());
				jteOutput.writeContent("</div>\r\n                            ");
			}
			jteOutput.writeContent("\r\n                        ");
		} else {
			jteOutput.writeContent("\r\n                            <div>👋 Hi! Ask me for book recommendations!</div>\r\n                        ");
		}
		jteOutput.writeContent("\r\n                    </div>\r\n\r\n                    <form method=\"post\" action=\"/ask\" class=\"d-flex mt-auto\">\r\n                        <input type=\"text\" name=\"prompt\" class=\"form-control me-2\"\r\n                               placeholder=\"Recommend me a book about...\" required>\r\n                        <button class=\"btn btn-primary\">Send</button>\r\n                    </form>\r\n\r\n\r\n                </div>\r\n            </div>\r\n        </div>\r\n\r\n        ");
		jteOutput.writeContent("\r\n        <div class=\"col-md-6\">\r\n            <div class=\"card shadow-lg h-100\">\r\n                <div class=\"card-header bg-success text-white\">\r\n                    🔍 Search Google Books\r\n                </div>\r\n                <div class=\"card-body\">\r\n\r\n                    <div class=\"d-flex mb-2\">\r\n                        <input id=\"search\" type=\"text\" class=\"form-control me-2\" placeholder=\"Search books...\">\r\n                        <button class=\"btn btn-success\" onclick=\"searchBook()\">Search</button>\r\n                    </div>\r\n\r\n                    <div id=\"results\" style=\"height:350px; overflow-y:auto;\"></div>\r\n\r\n                </div>\r\n            </div>\r\n        </div>\r\n\r\n    </div>\r\n</div>\r\n\r\n");
		jteOutput.writeContent("\r\n<script>\r\n    function searchBook() {\r\n        const q = document.getElementById(\"search\").value;\r\n\r\n        fetch(`/api/searchBooks?q=${encodeURIComponent(q)}`)\r\n            .then(res => res.json())\r\n            .then(data => {\r\n                const results = document.getElementById(\"results\");\r\n                results.innerHTML = \"\";\r\n\r\n                if (!data.items) {\r\n                    results.innerHTML = \"<p>No results found</p>\";\r\n                    return;\r\n                }\r\n\r\n                data.items.forEach(book => {\r\n                    const info = book.volumeInfo;\r\n                    const title = info.title || \"No Title\";\r\n                    const authors = info.authors ? info.authors.join(\", \") : \"Unknown Author\";\r\n                    const thumbnail = info.imageLinks && info.imageLinks.thumbnail ? info.imageLinks.thumbnail : \"\";\r\n\r\n                    results.innerHTML += `\r\n                    <div class=\"d-flex mb-3 border p-2 rounded\">\r\n                        <img src=\"${thumbnail}\" style=\"height:100px; margin-right:10px;\">\r\n                        <div>\r\n                            <strong>${title}</strong><br>\r\n                            <em>${authors}</em>\r\n                        </div>\r\n                    </div>\r\n                `;\r\n                });\r\n            });\r\n    }\r\n</script>\r\n");
		jteOutput.writeContent("\r\n</body>\r\n</html>");
	}
	public static void renderMap(gg.jte.html.HtmlTemplateOutput jteOutput, gg.jte.html.HtmlInterceptor jteHtmlInterceptor, java.util.Map<String, Object> params) {
		List<Exchange> history = (List<Exchange>)params.get("history");
		render(jteOutput, jteHtmlInterceptor, history);
	}
}
