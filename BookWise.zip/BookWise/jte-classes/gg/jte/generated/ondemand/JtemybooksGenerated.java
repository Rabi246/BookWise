package gg.jte.generated.ondemand;
@SuppressWarnings("unchecked")
public final class JtemybooksGenerated {
	public static final String JTE_NAME = "mybooks.jte";
	public static final int[] JTE_LINE_INFO = {0,0,0,0,0,10,10,29,29,36,36,36,42,42,53,53,56,60,60,64,64,64,64,64,64,64,64,64,65,65,65,65,65,65,65,65,65,66,66,66,66,66,66,66,66,66,67,67,67,67,67,67,67,67,67,68,68,68,68,68,68,68,68,68,69,69,69,69,69,69,69,69,69,71,71,75,82,82,93,93,96,163,168,168,168,0,1,1,1,1};
	public static void render(gg.jte.html.HtmlTemplateOutput jteOutput, gg.jte.html.HtmlInterceptor jteHtmlInterceptor, String username, java.util.List<org.example.bookwise.model.Book> books) {
		jteOutput.writeContent("<!DOCTYPE html>\r\n<html lang=\"en\">\r\n<head>\r\n    <meta charset=\"UTF-8\">\r\n    <title>My Books | BookWise</title>\r\n    <link href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css\" rel=\"stylesheet\">\r\n    <link href=\"https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css\" rel=\"stylesheet\">\r\n    <link rel=\"stylesheet\" href=\"/css/style.css\">\r\n    <link rel=\"stylesheet\" href=\"/css/mybooks.css\">");
		jteOutput.writeContent("\r\n</head>\r\n\r\n<body class=\"bg-light\">\r\n<nav class=\"navbar navbar-expand-lg navbar-dark bg-dark mb-4\">\r\n    <div class=\"container-fluid\">\r\n        <a class=\"navbar-brand\" href=\"/home_page\">📚 BookWise</a>\r\n\r\n        <button class=\"navbar-toggler\" type=\"button\" data-bs-toggle=\"collapse\" data-bs-target=\"#navbarNav\">\r\n            <span class=\"navbar-toggler-icon\"></span>\r\n        </button>\r\n\r\n        <div class=\"collapse navbar-collapse\" id=\"navbarNav\">\r\n            <ul class=\"navbar-nav me-auto mb-2 mb-lg-0\">\r\n                <li class=\"nav-item\"><a class=\"nav-link active\" href=\"/mybooks\">My Library</a></li>\r\n                <li class=\"nav-item\"><a class=\"nav-link\" href=\"/home_page\">Recommendations</a></li>\r\n                <li class=\"nav-item\"><a class=\"nav-link\" href=\"/booksearch\">Search</a></li>\r\n            </ul>\r\n\r\n            ");
		if (username != null) {
			jteOutput.writeContent("\r\n                <div class=\"d-flex align-items-center\">\r\n                    <div class=\"dropdown\">\r\n                        <button class=\"btn btn-outline-light btn-sm dropdown-toggle\" type=\"button\" id=\"userDropdown\" data-bs-toggle=\"dropdown\" aria-expanded=\"false\">\r\n                            <i class=\"bi bi-person-circle\" style=\"font-size: 2rem\"></i>\r\n                        </button>\r\n                        <ul class=\"dropdown-menu dropdown-menu-end\" aria-labelledby=\"userDropdown\">\r\n                            <li><span class=\"dropdown-item-text fw-bold\">");
			jteOutput.setContext("span", null);
			jteOutput.writeUserContent(username);
			jteOutput.writeContent("</span></li>\r\n                            <li><hr class=\"dropdown-divider\"></li>\r\n                            <li><a class=\"dropdown-item text-danger\" href=\"/logout\">Logout</a></li>\r\n                        </ul>\r\n                    </div>\r\n                </div>\r\n            ");
		}
		jteOutput.writeContent("\r\n        </div>\r\n    </div>\r\n</nav>\r\n\r\n<div class=\"container-fluid px-4 page-content\">\r\n    <div class=\"text-center mb-4\">\r\n        <h2 class=\"fw-bold\">📘 My Library</h2>\r\n        <p class=\"text-muted\">Your saved books collection</p>\r\n    </div>\r\n\r\n    ");
		if (books != null && !books.isEmpty()) {
			jteOutput.writeContent("\r\n        <div class=\"mylibrary-page\">\r\n            <div id=\"library-container\">\r\n                ");
			jteOutput.writeContent("\r\n                <div id=\"library-left\">\r\n                    <h2>My Library</h2>\r\n                    <div class=\"book-grid\">\r\n                        ");
			for (var book : books) {
				jteOutput.writeContent("\r\n                            <div\r\n                                    class=\"book-card\"\r\n                                    onclick=\"showDetails(this)\"\r\n                                   ");
				var __jte_html_attribute_0 = book.getId();
				if (gg.jte.runtime.TemplateUtils.isAttributeRendered(__jte_html_attribute_0)) {
					jteOutput.writeContent(" data-id=\"");
					jteOutput.setContext("div", "data-id");
					jteOutput.writeUserContent(__jte_html_attribute_0);
					jteOutput.setContext("div", null);
					jteOutput.writeContent("\"");
				}
				jteOutput.writeContent("\r\n                                   ");
				var __jte_html_attribute_1 = book.getTitle();
				if (gg.jte.runtime.TemplateUtils.isAttributeRendered(__jte_html_attribute_1)) {
					jteOutput.writeContent(" data-name=\"");
					jteOutput.setContext("div", "data-name");
					jteOutput.writeUserContent(__jte_html_attribute_1);
					jteOutput.setContext("div", null);
					jteOutput.writeContent("\"");
				}
				jteOutput.writeContent("\r\n                                   ");
				var __jte_html_attribute_2 = book.getAuthors();
				if (gg.jte.runtime.TemplateUtils.isAttributeRendered(__jte_html_attribute_2)) {
					jteOutput.writeContent(" data-author=\"");
					jteOutput.setContext("div", "data-author");
					jteOutput.writeUserContent(__jte_html_attribute_2);
					jteOutput.setContext("div", null);
					jteOutput.writeContent("\"");
				}
				jteOutput.writeContent("\r\n                                   ");
				var __jte_html_attribute_3 = book.getDescription() == null ? "" : book.getDescription();
				if (gg.jte.runtime.TemplateUtils.isAttributeRendered(__jte_html_attribute_3)) {
					jteOutput.writeContent(" data-summary=\"");
					jteOutput.setContext("div", "data-summary");
					jteOutput.writeUserContent(__jte_html_attribute_3);
					jteOutput.setContext("div", null);
					jteOutput.writeContent("\"");
				}
				jteOutput.writeContent("\r\n                                   ");
				var __jte_html_attribute_4 = book.getThumbnail();
				if (gg.jte.runtime.TemplateUtils.isAttributeRendered(__jte_html_attribute_4)) {
					jteOutput.writeContent(" data-picture=\"");
					jteOutput.setContext("div", "data-picture");
					jteOutput.writeUserContent(__jte_html_attribute_4);
					jteOutput.setContext("div", null);
					jteOutput.writeContent("\"");
				}
				jteOutput.writeContent(">\r\n                                <img");
				var __jte_html_attribute_5 = book.getThumbnail();
				if (gg.jte.runtime.TemplateUtils.isAttributeRendered(__jte_html_attribute_5)) {
					jteOutput.writeContent(" src=\"");
					jteOutput.setContext("img", "src");
					jteOutput.writeUserContent(__jte_html_attribute_5);
					jteOutput.setContext("img", null);
					jteOutput.writeContent("\"");
				}
				jteOutput.writeContent(" class=\"book-cover\" alt=\"Cover\">\r\n                            </div>\r\n                        ");
			}
			jteOutput.writeContent("\r\n                    </div>\r\n                </div>\r\n\r\n                ");
			jteOutput.writeContent("\r\n                <div id=\"details-panel\" class=\"hidden\">\r\n                    <button onclick=\"hideDetails()\" class=\"close-btn\" aria-label=\"Close\">✖</button>\r\n                    <div id=\"details-content\">Select a book...</div>\r\n                </div>\r\n            </div>\r\n        </div>\r\n    ");
		} else {
			jteOutput.writeContent("\r\n        <div class=\"card shadow-sm mt-4\">\r\n            <div class=\"card-body text-center py-5\">\r\n                <i class=\"bi bi-book text-secondary\" style=\"font-size: 4rem;\"></i>\r\n                <h5 class=\"text-secondary mt-3\">Your library is empty</h5>\r\n                <p class=\"text-muted\">Start adding books from recommendations or search!</p>\r\n                <a href=\"/home_page\" class=\"btn btn-primary mt-3\">\r\n                    <i class=\"bi bi-search\"></i> Browse Books\r\n                </a>\r\n            </div>\r\n        </div>\r\n    ");
		}
		jteOutput.writeContent("\r\n</div>\r\n\r\n");
		jteOutput.writeContent("\r\n<script>\r\n    function showDetails(el) {\r\n        var data = el.dataset;\r\n        var panel = document.getElementById('details-panel');\r\n        var content = document.getElementById('details-content');\r\n        panel.classList.remove('hidden');\r\n\r\n        var name = data.name || 'Untitled';\r\n        var author = data.author || 'Unknown';\r\n        var summary = data.summary || 'No description';\r\n        var picture = data.picture || '';\r\n        var id = data.id || '';\r\n\r\n        var html = ''\r\n            + '<img src=\"' + picture + '\" style=\"width:250px;height:350px;object-fit:cover;border-radius:8px;\"><br><br>'\r\n            + '<h2>' + name + '</h2>'\r\n            + '<p><strong>Author:</strong> ' + author + '</p>'\r\n            + '<p><strong>Summary:</strong> ' + summary + '</p>'\r\n            + '<div class=\"rating\" data-book=\"' + id + '\">'\r\n            + '  <div style=\"margin-top:8px;margin-bottom:4px;\">'\r\n            + '    <strong>Your rating:</strong> '\r\n            + '    <span class=\"stars\" aria-label=\"Rate this book\">'\r\n            + '      <button type=\"button\" class=\"star\" data-value=\"1\">★</button>'\r\n            + '      <button type=\"button\" class=\"star\" data-value=\"2\">★</button>'\r\n            + '      <button type=\"button\" class=\"star\" data-value=\"3\">★</button>'\r\n            + '      <button type=\"button\" class=\"star\" data-value=\"4\">★</button>'\r\n            + '      <button type=\"button\" class=\"star\" data-value=\"5\">★</button>'\r\n            + '    </span>'\r\n            + '  </div>'\r\n            + '</div>'\r\n            + '<button onclick=\"removeBook(\\'' + id + '\\')\" class=\"btn btn-danger mt-3\">Remove From My Library</button>';\r\n\r\n        content.innerHTML = html;\r\n        wireRatingHandlers();\r\n    }\r\n\r\n    function hideDetails() {\r\n        document.getElementById('details-panel').classList.add('hidden');\r\n    }\r\n\r\n    function wireRatingHandlers() {\r\n        document.querySelectorAll('.rating .star').forEach(function(btn) {\r\n            btn.addEventListener('click', function() {\r\n                var value = btn.dataset.value;\r\n                var wrap = btn.closest('.rating');\r\n                wrap.querySelectorAll('.star').forEach(function(s) {\r\n                    if (Number(s.dataset.value) <= Number(value)) s.setAttribute('data-selected', '1');\r\n                    else s.removeAttribute('data-selected');\r\n                });\r\n                // TODO: POST rating to backend if needed\r\n            }, { once: true });\r\n        });\r\n    }\r\n\r\n    function removeBook(bookId) {\r\n        if (!confirm('Remove this book from your library?')) return;\r\n\r\n        fetch('/api/removeBook?bookId=' + encodeURIComponent(bookId), { method: 'POST' })\r\n            .then(function(res) { return res.json(); })\r\n            .then(function(data) {\r\n                if (data && data.success) window.location.reload();\r\n                else alert('Failed to remove book' + (data && data.message ? (': ' + data.message) : ''));\r\n            })\r\n            .catch(function() { alert('Error removing book from library'); });\r\n    }\r\n</script>\r\n");
		jteOutput.writeContent("\r\n\r\n<div class=\"auth-footer\"><i class=\"bi bi-bookmark-fill\"></i> BookWise.io © 2025 AI Book Recommendations.</div>\r\n<script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js\"></script>\r\n</body>\r\n</html>");
	}
	public static void renderMap(gg.jte.html.HtmlTemplateOutput jteOutput, gg.jte.html.HtmlInterceptor jteHtmlInterceptor, java.util.Map<String, Object> params) {
		String username = (String)params.get("username");
		java.util.List<org.example.bookwise.model.Book> books = (java.util.List<org.example.bookwise.model.Book>)params.get("books");
		render(jteOutput, jteHtmlInterceptor, username, books);
	}
}
