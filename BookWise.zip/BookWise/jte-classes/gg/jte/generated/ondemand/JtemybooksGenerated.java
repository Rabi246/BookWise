package gg.jte.generated.ondemand;
import org.example.bookwise.model.Book;
import java.util.List;
@SuppressWarnings("unchecked")
public final class JtemybooksGenerated {
	public static final String JTE_NAME = "mybooks.jte";
	public static final int[] JTE_LINE_INFO = {0,0,1,2,2,2,2,32,32,32,34,34,34,37,37,49,49,51,51,56,56,56,56,56,56,56,56,56,63,63,63,64,64,64,65,65,66,66,67,67,68,68,68,69,69,71,71,71,71,79,79,81,81,82,93,93,97,122,126,126,126,2,3,3,3,3};
	public static void render(gg.jte.html.HtmlTemplateOutput jteOutput, gg.jte.html.HtmlInterceptor jteHtmlInterceptor, String username, List<Book> books) {
		jteOutput.writeContent("\r\n<!DOCTYPE html>\r\n<html lang=\"en\">\r\n<head>\r\n    <meta charset=\"UTF-8\">\r\n    <title>My Books | BookWise</title>\r\n    <link href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css\" rel=\"stylesheet\">\r\n    <link href=\"https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css\" rel=\"stylesheet\">\r\n    <link rel=\"stylesheet\" href=\"/css/style.css\">\r\n</head>\r\n\r\n<body class=\"bg-light\">\r\n<script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js\"></script>\r\n<nav class=\"navbar navbar-expand-lg navbar-dark bg-dark mb-4\">\r\n    <div class=\"container-fluid\">\r\n        <a class=\"navbar-brand\" href=\"/home_page\">📚 BookWise</a>\r\n\r\n        <button class=\"navbar-toggler\" type=\"button\" data-bs-toggle=\"collapse\" data-bs-target=\"#navbarNav\">\r\n            <span class=\"navbar-toggler-icon\"></span>\r\n        </button>\r\n\r\n        <div class=\"collapse navbar-collapse\" id=\"navbarNav\">\r\n            <ul class=\"navbar-nav me-auto mb-2 mb-lg-0\">\r\n                <li class=\"nav-item\"><a class=\"nav-link active\" href=\"/mybooks\">My Library</a></li>\r\n                <li class=\"nav-item\"><a class=\"nav-link \" href=\"/home_page\">Recommendations</a></li>\r\n                <li class=\"nav-item\"><a class=\"nav-link\" href=\"/booksearch\">Search</a></li>\r\n            </ul>\r\n\r\n            ");
		if (username != null) {
			jteOutput.writeContent("\r\n                <div class=\"d-flex align-items-center\">\r\n                    <span class=\"navbar-text text-white me-3\">Welcome, ");
			jteOutput.setContext("span", null);
			jteOutput.writeUserContent(username);
			jteOutput.writeContent("</span>\r\n                    <a class=\"btn btn-outline-light btn-sm\" href=\"/logout\">Logout</a>\r\n                </div>\r\n            ");
		}
		jteOutput.writeContent("\r\n        </div>\r\n    </div>\r\n</nav>\r\n\r\n<div class=\"container-fluid px-4 page-content\">\r\n\r\n    <div class=\"text-center mb-4\">\r\n        <h2 class=\"fw-bold\">📘 My Library</h2>\r\n        <p class=\"text-muted\">Your saved books collection</p>\r\n    </div>\r\n\r\n    ");
		if (books != null && !books.isEmpty()) {
			jteOutput.writeContent("\r\n        <div class=\"row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4\">\r\n            ");
			for (var book : books) {
				jteOutput.writeContent("\r\n                <div class=\"col\">\r\n                    <div class=\"card h-100 shadow-sm\">\r\n                        <div class=\"row g-0\">\r\n                            <div class=\"col-4\">\r\n                                <img");
				var __jte_html_attribute_0 = book.getThumbnail();
				if (gg.jte.runtime.TemplateUtils.isAttributeRendered(__jte_html_attribute_0)) {
					jteOutput.writeContent(" src=\"");
					jteOutput.setContext("img", "src");
					jteOutput.writeUserContent(__jte_html_attribute_0);
					jteOutput.setContext("img", null);
					jteOutput.writeContent("\"");
				}
				jteOutput.writeContent("\r\n                                     class=\"img-fluid rounded-start h-100\"\r\n                                     style=\"object-fit: cover; max-height: 200px;\"\r\n                                     alt=\"Book cover\">\r\n                            </div>\r\n                            <div class=\"col-8\">\r\n                                <div class=\"card-body d-flex flex-column h-100\">\r\n                                    <h6 class=\"card-title text-primary fw-bold\">");
				jteOutput.setContext("h6", null);
				jteOutput.writeUserContent(book.getTitle());
				jteOutput.writeContent("</h6>\r\n                                    <p class=\"card-text text-warning small mb-2\">by ");
				jteOutput.setContext("p", null);
				jteOutput.writeUserContent(book.getAuthors());
				jteOutput.writeContent("</p>\r\n                                    ");
				if (book.getDescription() != null && !book.getDescription().isEmpty()) {
					jteOutput.writeContent("\r\n                                        ");
					var desc = book.getDescription();
					jteOutput.writeContent("\r\n                                        ");
					var truncated = desc.length() > 100 ? desc.substring(0, 100) + "..." : desc;
					jteOutput.writeContent("\r\n                                        <p class=\"card-text small text-secondary flex-grow-1\">");
					jteOutput.setContext("p", null);
					jteOutput.writeUserContent(truncated);
					jteOutput.writeContent("</p>\r\n                                    ");
				}
				jteOutput.writeContent("\r\n                                    <button class=\"btn btn-danger btn-sm mt-auto\"\r\n                                            onclick=\"removeBook('");
				jteOutput.setContext("button", "onclick");
				jteOutput.writeUserContent(book.getId());
				jteOutput.setContext("button", null);
				jteOutput.writeContent("')\">\r\n                                        <i class=\"bi bi-trash\"></i> Remove\r\n                                    </button>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n            ");
			}
			jteOutput.writeContent("\r\n        </div>\r\n    ");
		} else {
			jteOutput.writeContent("\r\n        ");
			jteOutput.writeContent("\r\n        <div class=\"card shadow-sm mt-4\">\r\n            <div class=\"card-body text-center py-5\">\r\n                <i class=\"bi bi-book text-secondary\" style=\"font-size: 4rem;\"></i>\r\n                <h5 class=\"text-secondary mt-3\">Your library is empty</h5>\r\n                <p class=\"text-muted\">Start adding books from recommendations or search!</p>\r\n                <a href=\"/home_page\" class=\"btn btn-primary mt-3\">\r\n                    <i class=\"bi bi-search\"></i> Browse Books\r\n                </a>\r\n            </div>\r\n        </div>\r\n    ");
		}
		jteOutput.writeContent("\r\n\r\n</div>\r\n\r\n");
		jteOutput.writeContent("\r\n<script>\r\n    function removeBook(bookId) {\r\n        if (!confirm('Remove this book from your library?')) {\r\n            return;\r\n        }\r\n\r\n        fetch(`/api/removeBook?bookId=${encodeURIComponent(bookId)}`, {\r\n            method: 'POST'\r\n        })\r\n            .then(res => res.json())\r\n            .then(data => {\r\n                if (data.success) {\r\n                    // Reload page to show updated library\r\n                    window.location.reload();\r\n                } else {\r\n                    alert('Failed to remove book: ' + data.message);\r\n                }\r\n            })\r\n            .catch(err => {\r\n                console.error('Error:', err);\r\n                alert('Error removing book from library');\r\n            });\r\n    }\r\n</script>\r\n");
		jteOutput.writeContent("\r\n<div class=\"auth-footer\"><i class=\"bi bi-bookmark-fill\"></i> BookWise.io © 2025 AI Book Recommendations.</div>\r\n<script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js\"></script>\r\n</body>\r\n</html>");
	}
	public static void renderMap(gg.jte.html.HtmlTemplateOutput jteOutput, gg.jte.html.HtmlInterceptor jteHtmlInterceptor, java.util.Map<String, Object> params) {
		String username = (String)params.get("username");
		List<Book> books = (List<Book>)params.get("books");
		render(jteOutput, jteHtmlInterceptor, username, books);
	}
}
