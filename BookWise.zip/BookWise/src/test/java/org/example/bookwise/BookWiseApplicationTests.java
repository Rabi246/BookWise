package org.example.bookwise;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookWiseApplicationTests {

	@Test
	void contextLoads() {
	}

}
