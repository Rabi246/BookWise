package org.example.bookwise;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookWiseApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookWiseApplication.class, args);
	}

}
